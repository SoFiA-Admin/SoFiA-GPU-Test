#ifndef TEST_LinkerPar_H
#define TEST_LinkerPar_H

#include <check.h>

Suite *LinkerPar_test_suite (void);

#endif