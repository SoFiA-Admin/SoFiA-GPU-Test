/// ____________________________________________________________________ ///
///                                                                      ///
/// SoFiA 2.5.1 (DataCubeOCL.c) - Source Finding Application (OpenCL)    ///
/// Copyright (C) 2023 The SoFiA 2 Authors & Integrated Systems Lab UPM  ///
/// ____________________________________________________________________ ///
///                                                                      ///
/// Address:  Tobias Westmeier                                           ///
///           ICRAR M468                                                 ///
///           The University of Western Australia                        ///
///           35 Stirling Highway                                        ///
///           Crawley WA 6009                                            ///
///           Australia                                                  ///
///                                                                      ///
/// E-mail:   tobias.westmeier [at] uwa.edu.au                           ///
/// ____________________________________________________________________ ///
///                                                                      ///
/// This program is free software: you can redistribute it and/or modify ///
/// it under the terms of the GNU General Public License as published by ///
/// the Free Software Foundation, either version 3 of the License, or    ///
/// (at your option) any later version.                                  ///
///                                                                      ///
/// This program is distributed in the hope that it will be useful,      ///
/// but WITHOUT ANY WARRANTY; without even the implied warranty of       ///
/// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the         ///
/// GNU General Public License for more details.                         ///
///                                                                      ///
/// You should have received a copy of the GNU General Public License    ///
/// along with this program. If not, see http://www.gnu.org/licenses/.   ///
/// ____________________________________________________________________ ///
///                                                                      ///

/// @file   DataCube.c
/// @author Tobias Westmeier & Integrated Systems Lab UPM
/// @date   2/1/2023
/// @brief  Class for source finding of FITS data cubes (CUDA).


#include "DataCubeOCL.h"



/// @brief Variant of copy constructor
///
/// Alternative copy constructor. Will create a new DataCube
/// object that is a physical copy of the object pointed to
/// by source (including memory allocation for the data array)
/// but it will not copy any data from the source. A pointer
/// to the newly created object will be returned. Note that the
/// destructor will need to be called explicitly once the object
/// is no longer required to release any memory allocated to the
/// object.
///
/// @param source  Pointer to DataCube object to be copied.
///
/// @return Pointer to newly created DataCube object.

PUBLIC DataCube *DataCube_copyempty(const DataCube *source)
{
	// Sanity checks
	check_null(source);
	
	DataCube *self = DataCube_new(source->verbosity);
	
	// Copy header
	self->header = Header_copy(source->header);
	
	// Copy data
	self->data = (char *)memory(MALLOC, source->data_size, source->word_size * sizeof(char));
	
	// Copy remaining properties
	self->data_size    = source->data_size;
	self->data_type    = source->data_type;
	self->word_size    = source->word_size;
	self->dimension    = source->dimension;
	self->axis_size[0] = source->axis_size[0];
	self->axis_size[1] = source->axis_size[1];
	self->axis_size[2] = source->axis_size[2];
	self->axis_size[3] = source->axis_size[3];
	
	return self;
}



/// @brief Apply boxcar filter to spectral axis (OpenCL)
///
/// Public method for convolving each spectrum of the data cube
/// with a boxcar filter of size 2 * radius + 1. The algorithm is
/// NaN-safe by setting all NaN values to 0 prior to filtering. Any
/// pixel outside of the cube's spectral range is also assumed to
/// be 0.
///
/// @param cube       Pointer to data cube.
/// @param radius     Filter radius in channels.
/// @param sizeX      Cube elements in the X dimension.
/// @param sizeY      Cube elements in the Y dimension.
/// @param sizeZ      Cube elements in the Z dimension.
/// @param cubeSize   Cube size in bytes.
/// @param context    OpenCL context.
/// @param queue      OpenCL command queue.
/// @param buffer     OpenCL mem buffer.
/// @param kernel     OpenCL kernel.

PUBLIC void DataCube_boxcar_filter_OCL(DataCube *cube, size_t radius, size_t sizeX, size_t sizeY, size_t sizeZ, size_t cubeSize, cl_context context, cl_command_queue queue, cl_mem buffer, cl_kernel kernel)
{
	// Sanity checks
	if(radius < 1) return;

	int size_z =  (int)sizeZ;
	int radiusData= (int)radius;
	float *dataRadiusZ;
	dataRadiusZ = (float*)calloc(sizeY * sizeX * (radius + 2), sizeof(float));
	size_t zRadiusSize = (size_t)(sizeY * sizeX * (radius + 2) * sizeof(float));

	cl_int numErr;
	cl_event boxcar_events[2];
	size_t zFilterGlobalWorkSize[3] = {sizeX, sizeY, 1};

	cl_mem ZRadiusData = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, zRadiusSize, dataRadiusZ , &numErr);
	numErr = clSetKernelArg(kernel, 0, sizeof(cl_mem), (void*)&buffer);
	numErr |= clSetKernelArg(kernel, 1, sizeof(cl_mem), (void*)&ZRadiusData);
	numErr |= clSetKernelArg(kernel, 2, sizeof(int), &radiusData);
	numErr |= clSetKernelArg(kernel, 3, sizeof(int), &size_z);

	numErr = clEnqueueNDRangeKernel(queue, kernel, 3, NULL, zFilterGlobalWorkSize, NULL, 0, NULL, &boxcar_events[1]);
	numErr = clWaitForEvents(1, &boxcar_events[1]);
	free(dataRadiusZ);

	// No necessity to update the host data cube because next function
	// (DataCube_gaussian_filter_OCL) uses the OpenCL buffer
	// numErr = clEnqueueReadBuffer(queue, buffer, CL_TRUE, 0, cubeSize, cube->data, 0, NULL, NULL);

	//clFinish(queue);
	clReleaseMemObject(ZRadiusData);
	return;
}




/// @ brief Apply 2D Gaussian filter to spatial planes (OpenCL)
///
/// Public method for convolving each spatial image plane (x-y) of
/// the data cube with a Gaussian function of standard deviation
/// sigma. The Gaussian convolution is approximated through a set
/// of 1D boxcar filters, which makes the algorithm extremely fast.
/// Limitations from this approach are that the resulting convolution
/// kernel is only an approximation of a Gaussian (although a fairly
/// accurate one) and the value of sigma can only be approximated
/// (typically within +/- 0.2 sigma) and must be at least 1.5 pixels.
/// The algorithm is NaN-safe by setting all NaN values to 0. Any
/// pixel outside of the image boundaries is also assumed to be 0.
///
/// @param cube       Pointer to data cube.
/// @param sigma      Standard deviation of the Gaussian in pixels.
/// @param sizeX      Cube elements in the X dimension.
/// @param sizeY      Cube elements in the Y dimension.
/// @param sizeZ      Cube elements in the Z dimension.
/// @param cubeSize   Cube size in bytes.
/// @param context    OpenCL context.
/// @param queue      OpenCL command queue.
/// @param buffer     OpenCL mem buffer.
/// @param kernelX    OpenCL kernel for X dimension.
/// @param kernelY    OpenCL kernel for Y dimension.

PUBLIC void DataCube_gaussian_filter_OCL(DataCube *cube, const double sigma, size_t sizeX, size_t sizeY, size_t sizeZ, size_t cubeSize, cl_context context, cl_command_queue queue, cl_mem buffer, cl_kernel kernelX, cl_kernel kernelY)
{
	// Set up parameters required for boxcar filter
	size_t n_iter;
	size_t filter_radius;
	optimal_filter_size_dbl(sigma, &filter_radius, &n_iter);
	int size_x = (int)sizeX;
	int size_y = (int)sizeY;
	int radius_filter = (int)filter_radius;
	cl_int numErr;
	cl_event X_filter_events[n_iter + 1];
	cl_event Y_filter_events[n_iter + 1];

	size_t xFilterGlobalWorkSize[3] = {1, sizeY, sizeZ};
	size_t yFilterGlobalWorkSize[3] = {sizeX, 1, sizeZ};

	float *dataRadiusX;
	dataRadiusX= (float*)calloc(sizeY * sizeZ * (filter_radius + 2), sizeof(float));
	size_t xRadiusSize = (size_t)(sizeY * sizeZ * (filter_radius + 2) * sizeof(float));

	cl_mem XRadiusData = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, xRadiusSize, dataRadiusX , &numErr);
	numErr = clSetKernelArg(kernelX, 0, sizeof(cl_mem), (void*)&buffer);    
	numErr |= clSetKernelArg(kernelX, 1, sizeof(cl_mem), (void*)&XRadiusData);
	numErr |= clSetKernelArg(kernelX, 2, sizeof(int), &radius_filter);
	numErr |= clSetKernelArg(kernelX, 3, sizeof(int), &size_x);

	size_t i;
	for(i = n_iter; i--;)
	{
		numErr=clEnqueueNDRangeKernel(queue, kernelX, 3, NULL, xFilterGlobalWorkSize, NULL, 0, NULL, &X_filter_events[i]);
		numErr = clWaitForEvents(1, &X_filter_events[i]);
	}
	free(dataRadiusX);

	float *dataRadiusY;
	dataRadiusY= (float*)calloc(sizeX * sizeZ * (filter_radius + 2), sizeof(float));
	size_t yRadiusSize = (size_t)(sizeX * sizeZ * (filter_radius + 2) * sizeof(float));

	cl_mem YRadiusData= clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, yRadiusSize, dataRadiusY , &numErr );
	numErr = clSetKernelArg(kernelY, 0, sizeof(cl_mem), (void*)&buffer);
	numErr |= clSetKernelArg(kernelY, 1, sizeof(cl_mem), (void*)&YRadiusData);
	numErr |= clSetKernelArg(kernelY, 2, sizeof(int), &radius_filter);
	numErr |= clSetKernelArg(kernelY, 3, sizeof(int), &size_y);

	for(i = n_iter; i--;)
	{
		numErr=clEnqueueNDRangeKernel(queue, kernelY, 3, NULL, yFilterGlobalWorkSize, NULL, 0, NULL, &Y_filter_events[i]);
		numErr = clWaitForEvents(1, &Y_filter_events[i]);
	}
	free(dataRadiusY);

	// No necessity to update the host data cube because next kernel
	// (OpenCL_DataCube_copy_blanked) uses the OpenCL buffer
	// numErr=clEnqueueReadBuffer(queue, buffer, CL_TRUE, 0, cubeSize, cube->data, 0, NULL, NULL);

	//clFinish(queue);
	clReleaseMemObject(XRadiusData);
	clReleaseMemObject(YRadiusData);
	return;
}



/// @brief Run Smooth + Clip (S+C) finder on data cube (OpenCL)
///
/// Method for running the **Smooth + Clip** (S+C) finder on
/// the specified data cube. The S+C finder will smooth the data on
/// the specified spatial and spectral scales, applying a Gaussian
/// filter in the spatial domain and a boxcar filter in the spectral
/// domain. It will then measure the noise level in each iteration
/// and mark all pixels with absolute values greater than or equal
/// to the specified threshold (relative to the noise level) as 1
/// in the specified mask cube, which must be of 8-bit integer
/// type, while non-detected pixels will be set to a value of 0.
/// Pixels already detected in a previous iteration will be set to
/// `maskScaleXY` times the original rms noise level of the data
/// before smoothing. If the value of `maskScaleXY` is negative, no
/// replacement will be carried out.
///
/// The input data cube must be a 32 or 64-bit floating point data
/// array. The spatial kernel sizes must be positive floating point
/// values that represent the FWHM of the Gaussian kernels to be
/// applied in the spatial domain. The spectral kernel sizes must
/// be positive, odd integer numbers representing the widths of the
/// boxcar filters to be applied in the spectral domain. The threshold
/// is relative to the noise level and should be a floating
/// point number greater than about 3.0. Lastly, the value of
/// `maskScaleXY` times the original rms of the data will be used to
/// replace pixels in the data cube that were already detected in a
/// previous iteration. This is to ensure that any sources in the
/// data will not be smeared out beyond the extent of the source
/// when convolving with large kernel sizes. It will, however,
/// create a positive bias in the flux measurement of the source and
/// can therefore be disabled by setting `maskScaleXY` to a negative
/// value.
///
/// Several methods are available for **measuring the noise** in the
/// data cube, including the standard deviation, median absolute
/// deviation and a Gaussian fit to the flux histogram. These
/// differ in their speed and robustness. In addition, the flux range
/// used in the noise measurement can be restricted to negative or
/// positive pixels only to reduce the impact or actual emission or
/// absorption featured on the noise measurement.
///
/// It is also possible to **renormalise the noise level** after each
/// smoothing operation by setting `scaleNoise` to a value of 1 or 2.
/// It should be noted that local noise normalisation on smoothed data
/// is risky, as the number of statistically independent data samples
/// may have become too low for a reliable measurement of the noise.
///
/// @param self          Data cube to run the S+C finder on.
/// @param maskCube      Mask cube for recording detected pixels.
/// @param kernels_spat  List of spatial smoothing lengths corresponding
///                      to the FWHM of the Gaussian kernels to be
///                      applied; 0 = no smoothing.
/// @param kernels_spec  List of spectral smoothing lengths corresponding
///                      to the widths of the boxcar filters to be
///                      applied. Must be odd or 0.
/// @param threshold     Relative flux threshold to be applied.
/// @param maskScaleXY   Already detected pixels will be set to this
///                      value times the original rms of the data
///                      before smoothing the data again. If negative,
///                      no replacement will be carried out.
/// @param method        Method to use for measuring the noise in
///                      the smoothed copies of the cube; can be
///                      `NOISE_STAT_STD`, `NOISE_STAT_MAD` or
///                      `NOISE_STAT_GAUSS` for standard deviation,
///                      median absolute deviation and Gaussian fit
///                      to flux histogram, respectively.
/// @param range         Flux range to used in noise measurement, Can
///                      be -1, 0 or 1 for negative only, all or
///                      positive only.
/// @param scaleNoise    0 = no noise scaling; 1 = global noise scaling;
///                      2 = local noise scaling. Applied after each
///                      smoothing operation.
/// @param snStatistic   Statistic to use in the noise scaling. Can
///                      be `NOISE_STAT_STD` for standard deviation,
///                      `NOISE_STAT_MAD` for median absolute deviation
///                      or `NOISE_STAT_GAUSS` for Gaussian fitting to
///                      the flux histogram.
/// @param snRange       Flux range to be used in the noise scaling.
///                      Can be -1, 0 or +1 for negative range, full
///                      range or positive range, respectively.
/// @param snWindowXY    Spatial window size for local noise scaling.
///                      See DataCube_scale_noise_local() for details.
/// @param snWindowZ     Spectral window size for local noise scaling
///                      See DataCube_scale_noise_local() for details.
/// @param snGridXY      Spatial grid size for local noise scaling.
///                      See DataCube_scale_noise_local() for details.
/// @param snGridZ       Spectral grid size for local noise scaling.
///                      See DataCube_scale_noise_local() for details.
/// @param snInterpol    Enable interpolation for local noise scaling
///                      if true. See DataCube_scale_noise_local()
///                      for details.
/// @param start_time    Arbitrary time stamp; progress time of the
///                      algorithm will be calculated and printed
///                      relative to `start_time`.
/// @param start_clock   Arbitrary clock count; progress time of the
///                      algorithm in term of CPU time will be
///                      calculated and printed relative to `clock_time`.

void DataCube_run_scfind_OCL(const DataCube *self, DataCube *maskCube, const Array_dbl *kernels_spat, const Array_siz *kernels_spec, const double threshold, const double maskScaleXY, const noise_stat method, const int range, const int scaleNoise, const noise_stat snStatistic, const int snRange, const size_t snWindowXY, const size_t snWindowZ, const size_t snGridXY, const size_t snGridZ, const bool snInterpol, const time_t start_time, const clock_t start_clock)
{
	message("\33[33mUsing OpenCL-based GPU acceleration\33[0m\n");
	// Sanity checks
	check_null(self);
	check_null(self->data);
	ensure(self->data_type < 0, ERR_USER_INPUT, "The S+C finder can only be applied to floating-point data.");
	check_null(maskCube);
	check_null(maskCube->data);
	ensure(maskCube->data_type == 8, ERR_USER_INPUT, "Mask cube must be of 8-bit integer type.");
	ensure(self->axis_size[0] == maskCube->axis_size[0] && self->axis_size[1] == maskCube->axis_size[1] && self->axis_size[2] == maskCube->axis_size[2], ERR_USER_INPUT, "Data cube and mask cube have different sizes.");
	check_null(kernels_spat);
	check_null(kernels_spec);
	ensure(Array_dbl_get_size(kernels_spat) && Array_siz_get_size(kernels_spec), ERR_USER_INPUT, "Invalid spatial or spectral kernel list encountered.");
	ensure(threshold >= 0.0, ERR_USER_INPUT, "Negative flux threshold encountered.");
	ensure(method == NOISE_STAT_STD || method == NOISE_STAT_MAD || method == NOISE_STAT_GAUSS, ERR_USER_INPUT, "Invalid noise measurement method: %d.", method);
	
	// A few additional settings
	const double FWHM_CONST = 2.0 * sqrt(2.0 * log(2.0));  // Conversion between sigma and FWHM of Gaussian function
	size_t cadence = self->data_size / NOISE_SAMPLE_SIZE;  // Stride for noise calculation
	if(cadence < 2) cadence = 1;
	else if(cadence % self->axis_size[0] == 0) cadence -= 1;    // Ensure stride is not equal to multiple of x-axis size
	message("Using a stride of %zu in noise measurement.\n", cadence);

	// OPENCL: Configuration variables
	cl_int errNum;
	cl_platform_id *platformIDs;
	cl_platform_id platform;
	cl_device_id *deviceIDs;
	cl_device_id device;
	cl_uint numPlatforms;
	cl_uint numDevices;
	cl_context context = NULL;
	cl_program program;
	cl_command_queue queue;

	// OPENCL: Get available platform
	errNum = clGetPlatformIDs(0, NULL, &numPlatforms);
	ensure(numPlatforms >= 1 && errNum == CL_SUCCESS, ERR_FAILURE, "Failed to find any OpenCL platforms.");
	platformIDs = (cl_platform_id*)calloc(numPlatforms, sizeof(cl_platform_id));
	errNum = clGetPlatformIDs(numPlatforms, platformIDs, NULL);
	ensure(errNum == CL_SUCCESS, ERR_FAILURE, "Failed to find any OpenCL platform IDs.");
	platform = platformIDs[0]; // First platform is assigned

	// OPENCL: Get available GPU device
	errNum = clGetDeviceIDs(platform, CL_DEVICE_TYPE_GPU, 0, NULL, &numDevices);
	ensure(numDevices >= 1 && errNum == CL_SUCCESS, ERR_FAILURE, "Failed to find any OpenCL GPU devices.");
	deviceIDs = (cl_device_id*)calloc(numDevices, sizeof(cl_device_id));
	errNum = clGetDeviceIDs(platform, CL_DEVICE_TYPE_GPU, numDevices, &deviceIDs[0], NULL);
	ensure(errNum == CL_SUCCESS, ERR_FAILURE, "Failed to find any OpenCL GPU device IDs.");
	device = deviceIDs[0]; // First device is assigned

	// OPENCL: Context creation for handling of queues, memory and kernels
	cl_context_properties contextProperties[] = {CL_CONTEXT_PLATFORM, (cl_context_properties)platform, 0};
	context = clCreateContext(contextProperties, numDevices, deviceIDs, NULL, NULL, &errNum);
	ensure(errNum == CL_SUCCESS, ERR_FAILURE, "Failed creating OpenCL context.");

	// OPENCL: Command queue creation
	queue = clCreateCommandQueue(context, device, 0, &errNum);
	ensure(errNum == CL_SUCCESS, ERR_FAILURE, "Failed creating OpenCL command queue.");

	// OPENCL: Source code file sizing for program creation
	const char* cFilename = "src/DataCubeKernel.cl";
	const char* cPreamble = "";
	size_t* szFinalLength = NULL;
	size_t szSourceLength;
	size_t szPreambleLength = strlen(cPreamble);
	FILE* pFileStream = NULL;

	pFileStream = fopen(cFilename, "rb");
	ensure(pFileStream, ERR_FILE_ACCESS, "Failed opening OpenCL source code file.");
	fseek(pFileStream, 0, SEEK_END);
	szSourceLength = ftell(pFileStream);
	fseek(pFileStream, 0, SEEK_SET);

	char* cSourceString = (char*)malloc(szSourceLength + szPreambleLength + 1);
	memcpy(cSourceString, cPreamble, szPreambleLength);
	if (fread((cSourceString) + szPreambleLength, szSourceLength, 1, pFileStream) != 1)
	{
		fclose(pFileStream);
		free(cSourceString);
		ensure(false, ERR_FILE_ACCESS, "Failed reading OpenCL source code file.");
	}
	fclose(pFileStream);
	if(szFinalLength != 0) *szFinalLength = szSourceLength + szPreambleLength;
	cSourceString[szSourceLength + szPreambleLength] = '\0';

	// OPENCL: Program creation and building
	program = clCreateProgramWithSource(context, 1, (const char**)&cSourceString, szFinalLength, &errNum);
	ensure(program != NULL, ERR_FAILURE, "Failed creating OpenCL program.");
	errNum = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
	if (errNum != CL_SUCCESS)
	{
		size_t log_size;
		clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG, 0, NULL, &log_size);
		char *log= (char*)malloc(log_size);
		clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG, log_size, log, NULL);
		printf("Build log:\n%s\n", log);
		ensure(false, ERR_FAILURE, "Failed building OpenCL program.");
	}

	// OPENCL: Kernels creation
	const char *kernel_name_1;
	const char *kernel_name_2;
	const char *kernel_name_3;
	const char *kernel_name_4;
	const char *kernel_name_5;
	const char *kernel_name_6;
	if (self->data_type == -32)
	{
		kernel_name_1 = "DataCube_set_masked_8_opencl_flt";
		kernel_name_2 = "DataCube_copy_blanked_opencl_flt";
		kernel_name_3 = "DataCube_mask_8_opencl_flt";
		kernel_name_4 = "Xfilters_flt_opencl";
		kernel_name_5 = "Yfilters_flt_opencl";
		kernel_name_6 = "Zfilters_flt_opencl";
	}
	else if (self->data_type == -64)
	{
		kernel_name_1 = "DataCube_set_masked_8_opencl_dbl";
		kernel_name_2 = "DataCube_copy_blanked_opencl_dbl";
		kernel_name_3 = "DataCube_mask_8_opencl_dbl";
		kernel_name_4 = "Xfilters_dbl_opencl";
		kernel_name_5 = "Yfilters_dbl_opencl";
		kernel_name_6 = "Zfilters_dbl_opencl";
	}

	cl_kernel OpenCL_DataCube_set_masked_8 = clCreateKernel(program, kernel_name_1, &errNum);
	ensure(OpenCL_DataCube_set_masked_8 != (cl_kernel)NULL && errNum == CL_SUCCESS, ERR_FAILURE, "Failed creating OpenCL kernel 1.");
	cl_kernel OpenCL_DataCube_copy_blanked = clCreateKernel(program, kernel_name_2, &errNum);
	ensure(OpenCL_DataCube_copy_blanked != (cl_kernel)NULL && errNum == CL_SUCCESS, ERR_FAILURE, "Failed creating OpenCL kernel 2.");
	cl_kernel OpenCL_DataCube_mask_8 = clCreateKernel(program, kernel_name_3, &errNum);
	ensure(OpenCL_DataCube_mask_8 != (cl_kernel)NULL && errNum == CL_SUCCESS, ERR_FAILURE, "Failed creating OpenCL kernel 3.");
	cl_kernel OpenCL_Xfilters = clCreateKernel(program, kernel_name_4, &errNum);
	cl_kernel OpenCL_Yfilters = clCreateKernel(program, kernel_name_5, &errNum);
	cl_kernel OpenCL_Zfilters = clCreateKernel(program, kernel_name_6, &errNum);

	// OPENCL: Sizes for threads and buffers, and auxiliary variables
	int *size_x = (int*)&(self->axis_size[0]);
	int *size_y = (int*)&(self->axis_size[1]);
	int *size_z = (int*)&(self->axis_size[2]);
	size_t globalWorkSize[3] = {self->axis_size[0], self->axis_size[1], self->axis_size[2]};
	size_t size = (size_t)(self->data_size * self->word_size * sizeof(char));
	size_t sizeMask = (size_t)(maskCube->data_size * maskCube->word_size * sizeof(char));
	cl_event K_events[7];
	double valueXY;
	double threshold_rms;

	// OPENCL: Creation of buffers
	cl_mem selfCubeBuf = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, size, self->data, &errNum );
	cl_mem maskCubeBuf = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, sizeMask, maskCube->data, &errNum);
	cl_mem smoothedCubeBuf = clCreateBuffer(context, CL_MEM_READ_WRITE, size, NULL, &errNum);

	// Measure noise in original cube with sampling "cadence"
	double rms;
	double rms_smooth;
	
	if(method == NOISE_STAT_STD)      rms = DataCube_stat_std(self, 0.0, cadence, range);
	else if(method == NOISE_STAT_MAD) rms = MAD_TO_STD * DataCube_stat_mad(self, 0.0, cadence, range);
	else                              rms = DataCube_stat_gauss(self, cadence, range);
	
	// Run S+C finder for all smoothing kernels
	size_t i;
	for(i = 0; i < Array_dbl_get_size(kernels_spat); ++i)
	{
		size_t j;
		for(j = 0; j < Array_siz_get_size(kernels_spec); ++j)
		{
			message("Smoothing kernel:  [%.1f] x [%zu]", Array_dbl_get(kernels_spat, i), Array_siz_get(kernels_spec, j));
			
			// Check if any smoothing requested
			if(Array_dbl_get(kernels_spat, i) || Array_siz_get(kernels_spec, j))
			{
				// Smoothing required; create a copy of the original cube
				//DataCube *smoothedCube = DataCube_copy(self);
				DataCube *smoothedCube = DataCube_copyempty(self);
				
				// Set flux of already detected pixels to maskScaleXY * rms
				//if(maskScaleXY >= 0.0) DataCube_set_masked_8(smoothedCube, maskCube, maskScaleXY * rms);
				if(maskScaleXY >= 0.0)
				{
					valueXY = maskScaleXY * rms;
					errNum = clSetKernelArg(OpenCL_DataCube_set_masked_8, 0, sizeof(cl_mem), (void*)&smoothedCubeBuf);
					errNum |= clSetKernelArg(OpenCL_DataCube_set_masked_8, 1, sizeof(cl_mem), (void*)&maskCubeBuf);
					errNum |= clSetKernelArg(OpenCL_DataCube_set_masked_8, 2, sizeof(cl_mem), (void*)&selfCubeBuf);
					errNum |= clSetKernelArg(OpenCL_DataCube_set_masked_8, 3, sizeof(double), &valueXY);
					errNum |= clSetKernelArg(OpenCL_DataCube_set_masked_8, 4, sizeof(int), &size_x);
					errNum |= clSetKernelArg(OpenCL_DataCube_set_masked_8, 5, sizeof(int), &size_y);
					errNum |= clSetKernelArg(OpenCL_DataCube_set_masked_8, 6, sizeof(int), &size_z);
					ensure(errNum == CL_SUCCESS, ERR_FAILURE, "Failed setting OpenCL kernel arguments.");
					errNum = clEnqueueNDRangeKernel(queue, OpenCL_DataCube_set_masked_8, 3, NULL, globalWorkSize, NULL, 0, NULL, &K_events[0]);
					ensure(errNum == CL_SUCCESS, ERR_FAILURE, "Failed launching OpenCL_DataCube_set_masked_8 kernel.");
					errNum = clWaitForEvents(1, &K_events[0]);
					clFinish(queue);
				}
				
				// Spatial and spectral smoothing
				//if(Array_dbl_get(kernels_spat, i) > 0.0) DataCube_gaussian_filter(smoothedCube, Array_dbl_get(kernels_spat, i) / FWHM_CONST);
				//if(Array_siz_get(kernels_spec, j) > 0)   DataCube_boxcar_filter(smoothedCube, Array_siz_get(kernels_spec, j) / 2);
				if(Array_dbl_get(kernels_spat, i) > 0.0) DataCube_gaussian_filter_OCL(smoothedCube, Array_dbl_get(kernels_spat, i) / FWHM_CONST, self->axis_size[0], self->axis_size[1], self->axis_size[2], size, context, queue, smoothedCubeBuf, OpenCL_Xfilters, OpenCL_Yfilters);
				if(Array_siz_get(kernels_spec, j) > 0) DataCube_boxcar_filter_OCL(smoothedCube, Array_siz_get(kernels_spec, j) / 2,  self->axis_size[0], self->axis_size[1], self->axis_size[2], size, context, queue, smoothedCubeBuf, OpenCL_Zfilters);

				// Copy original blanks into smoothed cube again
				// (these were set to 0 during smoothing)
				//DataCube_copy_blanked(smoothedCube, self);

				errNum = clSetKernelArg(OpenCL_DataCube_copy_blanked, 0, sizeof(cl_mem), (void*)&smoothedCubeBuf);
				errNum |= clSetKernelArg(OpenCL_DataCube_copy_blanked, 1, sizeof(cl_mem), (void*)&selfCubeBuf);
				errNum = clEnqueueNDRangeKernel(queue, OpenCL_DataCube_copy_blanked, 3, NULL, globalWorkSize, NULL, 0, NULL, &K_events[1]);
				ensure(errNum == CL_SUCCESS, ERR_FAILURE, "Failed launching OpenCL_DataCube_copy_blanked kernel.");
				errNum = clWaitForEvents(1, &K_events[1]);
				clFinish(queue);

				errNum = clEnqueueReadBuffer(queue, smoothedCubeBuf, CL_TRUE, 0, size, smoothedCube->data, 0, NULL, &K_events[2]);
				errNum = clWaitForEvents(1, &K_events[2]);
				
				// Scale noise if requested
				if(scaleNoise == 1)
				{
					message("Correcting for noise variations along spectral axis.\n");
					DataCube_scale_noise_spec(smoothedCube, snStatistic, snRange);
				}
				else if(scaleNoise == 2)
				{
					message("Correcting for local noise variations.");
					DataCube *noiseCube = DataCube_scale_noise_local(
						smoothedCube,
						snStatistic,
						snRange,
						snWindowXY,
						snWindowZ,
						snGridXY,
						snGridZ,
						snInterpol
					);
					DataCube_delete(noiseCube);
				}

				// Calculate the RMS of the smoothed cube
				if(method == NOISE_STAT_STD)      rms_smooth = DataCube_stat_std(smoothedCube, 0.0, cadence, range);
				else if(method == NOISE_STAT_MAD) rms_smooth = MAD_TO_STD * DataCube_stat_mad(smoothedCube, 0.0, cadence, range);
				else                              rms_smooth = DataCube_stat_gauss(smoothedCube, cadence, range);
				
				message("Noise level:       %.3e", rms_smooth);
				
				// Add pixels above threshold to mask
				//DataCube_mask_8(smoothedCube, maskCube, threshold * rms_smooth, 1);

				errNum = clEnqueueWriteBuffer(queue, smoothedCubeBuf, CL_TRUE, 0, size, smoothedCube->data, 0, NULL, &K_events[3]);
                                errNum = clWaitForEvents(1, &K_events[3]);

				threshold_rms = threshold * rms_smooth;
				errNum = clSetKernelArg(OpenCL_DataCube_mask_8, 0, sizeof(cl_mem), (void*)&smoothedCubeBuf);
				errNum |= clSetKernelArg(OpenCL_DataCube_mask_8, 1, sizeof(cl_mem), (void*)&maskCubeBuf);
				errNum |= clSetKernelArg(OpenCL_DataCube_mask_8, 2, sizeof(double), &threshold_rms);
				errNum = clEnqueueNDRangeKernel(queue, OpenCL_DataCube_mask_8, 3, NULL, globalWorkSize, NULL, 0, NULL, &K_events[4]);
				ensure(errNum == CL_SUCCESS, ERR_FAILURE, "Failed launching OpenCL_DataCube_mask_8 kernel.");
				errNum = clWaitForEvents(1, &K_events[4]);
				clFinish(queue);
				
				// Delete smoothed cube again
				DataCube_delete(smoothedCube);
			}
			else
			{
				// No smoothing required; apply threshold to original cube
				message("Noise level:       %.3e", rms);
				//DataCube_mask_8(self, maskCube, threshold * rms, 1);
				threshold_rms = threshold * rms;
				errNum = clSetKernelArg(OpenCL_DataCube_mask_8, 0, sizeof(cl_mem), (void*)&selfCubeBuf);
				errNum |= clSetKernelArg(OpenCL_DataCube_mask_8, 1, sizeof(cl_mem), (void*)&maskCubeBuf);
				errNum |= clSetKernelArg(OpenCL_DataCube_mask_8, 2, sizeof(double), &threshold_rms);
				errNum = clEnqueueNDRangeKernel(queue, OpenCL_DataCube_mask_8, 3, NULL, globalWorkSize, NULL, 0, NULL, &K_events[5]);
				errNum = clWaitForEvents(1, &K_events[5]);
				clFinish(queue);
			}
			
			// Print time
			timestamp(start_time, start_clock);
		}
	}

	errNum = clEnqueueReadBuffer(queue, maskCubeBuf, CL_TRUE, 0, sizeMask, maskCube->data, 0, NULL, &K_events[6]);
	errNum = clWaitForEvents(1, &K_events[6]);

	clReleaseKernel(OpenCL_DataCube_set_masked_8);
	clReleaseKernel(OpenCL_DataCube_copy_blanked);
	clReleaseKernel(OpenCL_DataCube_mask_8);
	clReleaseKernel(OpenCL_Xfilters);
	clReleaseKernel(OpenCL_Yfilters);
	clReleaseKernel(OpenCL_Zfilters);
	clReleaseProgram(program);
	free(cSourceString);
	clReleaseMemObject(selfCubeBuf);
	clReleaseMemObject(maskCubeBuf);
	clReleaseMemObject(smoothedCubeBuf);
	clReleaseCommandQueue(queue);
	clReleaseContext(context);
	free(platformIDs);
	free(deviceIDs);
	return;
}





