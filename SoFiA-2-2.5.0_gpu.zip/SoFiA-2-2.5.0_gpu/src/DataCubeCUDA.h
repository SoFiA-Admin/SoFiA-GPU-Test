/// ____________________________________________________________________ ///
///                                                                      ///
/// SoFiA 2.5.1 (DataCubeCUDA.h) - Source Finding Application (CUDA)     ///
/// Copyright (C) 2023 The SoFiA 2 Authors & Integrated Systems Lab UPM  ///
/// ____________________________________________________________________ ///
///                                                                      ///
/// Address:  Tobias Westmeier                                           ///
///           ICRAR M468                                                 ///
///           The University of Western Australia                        ///
///           35 Stirling Highway                                        ///
///           Crawley WA 6009                                            ///
///           Australia                                                  ///
///                                                                      ///
/// E-mail:   tobias.westmeier [at] uwa.edu.au                           ///
/// ____________________________________________________________________ ///
///                                                                      ///
/// This program is free software: you can redistribute it and/or modify ///
/// it under the terms of the GNU General Public License as published by ///
/// the Free Software Foundation, either version 3 of the License, or    ///
/// (at your option) any later version.                                  ///
///                                                                      ///
/// This program is distributed in the hope that it will be useful,      ///
/// but WITHOUT ANY WARRANTY; without even the implied warranty of       ///
/// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the         ///
/// GNU General Public License for more details.                         ///
///                                                                      ///
/// You should have received a copy of the GNU General Public License    ///
/// along with this program. If not, see http://www.gnu.org/licenses/.   ///
/// ____________________________________________________________________ ///
///                                                                      ///

/// @file   DataCube.h
/// @author Tobias Westmeier & Integrated Systems Lab UPM
/// @date   2/1/2023
/// @brief  Class for source finding of FITS data cubes (CUDA header).


#ifndef DATACUBECUDA_H
#define DATACUBECUDA_H

extern "C" {
	#include <stdlib.h>
	#include <stddef.h>
	#include <stdio.h>
	#include <string.h>
	#include <math.h>
	#include <stdint.h>
	#include <limits.h>

	#include "DataCube.h"
	#include "statistics_flt.h"
	#include "statistics_dbl.h"

	// ----------------------------------------------------------------- //
	// Declaration of properties of class DataCube                       //
	// ----------------------------------------------------------------- //

	CLASS DataCube
	{
		char   *data;
		size_t  data_size;
		Header *header;
		int     data_type;
		int     word_size;
		size_t  dimension;
		size_t  axis_size[4];
		bool    verbosity;
	};
}

#include <thrust/iterator/counting_iterator.h>
#include <thrust/iterator/transform_iterator.h>
#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/transform.h>
#include <thrust/remove.h>
#include <thrust/sort.h>
#include <thrust/extrema.h>
#include <thrust/pair.h>

// Device functions
__device__ void filter_boxcar_1d_flt_cuda(float *data, float *data_copy, const size_t size, const size_t filter_radius, size_t stride);

__device__ void filter_boxcar_1d_dbl_cuda(double *data, double *data_copy, const size_t size, const size_t filter_radius, size_t stride);

// CUDA kernels
__global__ void Xfilters_flt_cuda(char *data, char *data_prev, size_t radius, size_t sizeX, size_t sizeY, size_t sizeZ);

__global__ void Xfilters_dbl_cuda(char *data, char *data_prev, size_t radius, size_t sizeX, size_t sizeY, size_t sizeZ);

__global__ void Yfilters_flt_cuda(char *data, char *data_prev, size_t radius, size_t sizeX, size_t sizeY, size_t sizeZ);

__global__ void Yfilters_dbl_cuda(char *data, char *data_prev, size_t radius, size_t sizeX, size_t sizeY, size_t sizeZ);

__global__ void Zfilters_flt_cuda(char *data, char *data_prev, size_t radius, size_t sizeX, size_t sizeY, size_t sizeZ);

__global__ void Zfilters_dbl_cuda(char *data, char *data_prev, size_t radius, size_t sizeX, size_t sizeY, size_t sizeZ);

__global__ void histogram_flt_cuda(const float *data, const int size, const float data_min, const float data_max, int *histo);

__global__ void histogram_dbl_cuda(const double *data, const int size, const double data_min, const double data_max, int *histo);

__global__ void DataCube_mask_8_cuda(char* cube, char* maskCube, const double threshold, const uint8_t value, size_t sizeX, size_t sizeY, size_t sizeZ, int data_type);

__global__ void DataCube_copy_blanked_cuda(char* dest, char* source, size_t sizeX, size_t sizeY, size_t sizeZ, int data_type);

__global__ void DataCube_set_masked_8_cuda(char* cube, char* maskCube, const double value, size_t sizeX, size_t sizeY, size_t sizeZ, size_t data_type);

// Host functions
PUBLIC DataCube *DataCube_copy_CUDA(const DataCube *source, const char *data);

PUBLIC void DataCube_boxcar_filter_CUDA(char *cube, size_t radius, size_t sizeX, size_t sizeY, size_t sizeZ, int data_type);

PUBLIC void DataCube_gaussian_filter_CUDA(char *cube, const double sigma, size_t sizeX, size_t sizeY, size_t sizeZ, int data_type);

PUBLIC int Cutting_plane_flt_CUDA(thrust::device_vector<float>::iterator first, thrust::device_vector<float>::iterator last, int n, int k, float vmin, float vmax, double vsum, float* L, float* R, float* x, int* left, int* right);

PUBLIC int Cutting_plane_dbl_CUDA(thrust::device_vector<double>::iterator first, thrust::device_vector<double>::iterator last, int n, int k, double vmin, double vmax, double vsum, double* L, double* R, double* x, int* left, int* right);

PUBLIC double Median_flt_CUDA(thrust::device_vector<float>::iterator first, thrust::device_vector<float>::iterator last);

PUBLIC double Median_dbl_CUDA(thrust::device_vector<double>::iterator first, thrust::device_vector<double>::iterator last);

PUBLIC double DataCube_stat_std_CUDA(const char *cube, const size_t size, const double value, const size_t cadence, const int range, const int data_type);

PUBLIC double DataCube_stat_mad_CUDA(const char *cube, const size_t size, const double value, const size_t cadence, const int range, const int data_type);

PUBLIC double DataCube_stat_gauss_CUDA(const char *cube, const size_t size, const size_t cadence, const int range, const int data_type);

PUBLIC "C" void DataCube_run_scfind_CUDA(const DataCube *self, DataCube *maskCube, const Array_dbl *kernels_spat, const Array_siz *kernels_spec, const double threshold, const double maskScaleXY, const noise_stat method, const int range, const int scaleNoise, const noise_stat snStatistic, const int snRange, const size_t snWindowXY, const size_t snWindowZ, const size_t snGridXY, const size_t snGridZ, const bool snInterpol, const time_t start_time, const clock_t start_clock);

#endif
