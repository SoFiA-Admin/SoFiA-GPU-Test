/// ____________________________________________________________________ ///
///                                                                      ///
/// SoFiA 2.5.1 (DataCubeOCL.h) - Source Finding Application (OpenCL)    ///
/// Copyright (C) 2023 The SoFiA 2 Authors & Integrated Systems Lab UPM  ///
/// ____________________________________________________________________ ///
///                                                                      ///
/// Address:  Tobias Westmeier                                           ///
///           ICRAR M468                                                 ///
///           The University of Western Australia                        ///
///           35 Stirling Highway                                        ///
///           Crawley WA 6009                                            ///
///           Australia                                                  ///
///                                                                      ///
/// E-mail:   tobias.westmeier [at] uwa.edu.au                           ///
/// ____________________________________________________________________ ///
///                                                                      ///
/// This program is free software: you can redistribute it and/or modify ///
/// it under the terms of the GNU General Public License as published by ///
/// the Free Software Foundation, either version 3 of the License, or    ///
/// (at your option) any later version.                                  ///
///                                                                      ///
/// This program is distributed in the hope that it will be useful,      ///
/// but WITHOUT ANY WARRANTY; without even the implied warranty of       ///
/// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the         ///
/// GNU General Public License for more details.                         ///
///                                                                      ///
/// You should have received a copy of the GNU General Public License    ///
/// along with this program. If not, see http://www.gnu.org/licenses/.   ///
/// ____________________________________________________________________ ///
///                                                                      ///

/// @file   DataCube.h
/// @author Tobias Westmeier & Integrated Systems Lab UPM
/// @date   2/1/2023
/// @brief  Class for source finding of FITS data cubes (CUDA header).


#ifndef DATACUBEOCL_H
#define DATACUBEOCL_H

#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <limits.h>
#include <CL/cl.h>

#include "DataCube.h"
#include "statistics_flt.h"
#include "statistics_dbl.h"

// ----------------------------------------------------------------- //
// Declaration of properties of class DataCube                       //
// ----------------------------------------------------------------- //

CLASS DataCube
{
	char   *data;
	size_t  data_size;
	Header *header;
	int     data_type;
	int     word_size;
	size_t  dimension;
	size_t  axis_size[4];
	bool    verbosity;
};

// Host functions
PUBLIC DataCube  *DataCube_copyempty(const DataCube *source);

PUBLIC void DataCube_boxcar_filter_OCL(DataCube *cube, size_t radius, size_t sizeX, size_t sizeY, size_t sizeZ, size_t cubeSize, cl_context context, cl_command_queue queue, cl_mem buffer, cl_kernel kernel);

PUBLIC void DataCube_gaussian_filter_OCL(DataCube *cube, const double sigma, size_t sizeX, size_t sizeY, size_t sizeZ, size_t cubeSize, cl_context context, cl_command_queue queue, cl_mem buffer, cl_kernel kernelX, cl_kernel kernelY);

#endif
